set pages 9999
set lines 200
set tab off
set echo on
 
select /*+ MONITOR no_place_group_by */ 
  c.c_nation, min(l.lo_extendedprice), max(l.lo_extendedprice)
from linecust l, customer c
where l.lo_custkey = c.c_custkey
  and l.c_nation = c.c_nation
  and l.c_region = c.c_region
group by c.c_nation
fetch first 10 rows only;

select * from table(dbms_xplan.display_cursor(NULL,NULL));

set echo off
set trimspool on
set trim on
set pages 0
set linesize 1000
set long 1000000
set longchunksize 1000000

PROMPT Deep Vectorization Usage: ;
PROMPT ------------------------- ;
PROMPT ;

SELECT
  '   ' || deepvec.rowsource_id || ' - ' row_source_id,
    CASE
      WHEN deepvec.deepvec_hj IS NOT NULL
      THEN
        'deep vector hash joins used: ' || deepvec.deepvec_hj || 
        ', deep vector hash join flags: ' || deepvec.deepvec_hj_flags
      ELSE
        'deep vector HJ was NOT leveraged'
    END deep_vector_hash_join_usage_info
FROM
  (SELECT EXTRACT(DBMS_SQL_MONITOR.REPORT_SQL_MONITOR_XML,
    q'#//operation[@name='HASH JOIN' and @parent_id]#') xmldata
   FROM   DUAL) hj_operation_data,
  XMLTABLE('/operation'
    PASSING hj_operation_data.xmldata
    COLUMNS
     "ROWSOURCE_ID"        VARCHAR2(5) PATH '@id',
     "DEEPVEC_HJ"          VARCHAR2(5) PATH 'rwsstats/stat[@id="11"]',
     "DEEPVEC_HJ_FLAGS"    VARCHAR2(5) PATH 'rwsstats/stat[@id="12"]') deepvec;

