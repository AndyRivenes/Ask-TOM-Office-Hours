connect ssb/ssb@freepdb1
