@imlogin.sql

set pages 9999
set lines 200
set tab off
 
set serveroutput on
set echo on
 
alter session set statistics_level = all;
alter session set inmemory_deep_vectorization = false;

exec run_sysstats_pkg.rs_start;

select /*+ MONITOR */ count(l.lo_custkey)
from lineorder l
where l.lo_partkey IN (select p.p_partkey from part p)
and l.lo_quantity <= 3;

exec run_sysstats_pkg.rs_middle;

alter session set inmemory_deep_vectorization = true;

select /*+ MONITOR */ count(l.lo_custkey)
from lineorder l
where l.lo_partkey IN (select p.p_partkey from part p)
and l.lo_quantity <= 3;

exec run_sysstats_pkg.rs_stop(p_output => 'INMEMORY');
